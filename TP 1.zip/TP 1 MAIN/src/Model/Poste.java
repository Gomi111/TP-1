package Model;

public enum Poste {
    INGENIEURE_ETUDE_ET_DEVELOPPEMENT,
    TEAM_LEADER,
    PILOTE
}